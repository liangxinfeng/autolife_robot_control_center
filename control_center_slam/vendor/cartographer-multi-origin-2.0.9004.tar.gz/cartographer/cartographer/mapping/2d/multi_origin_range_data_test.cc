// Copyright 2026. Licensed under the Apache License, Version 2.0.
#include "cartographer/sensor/range_data.h"
#include "cartographer/mapping/2d/probability_grid.h"
#include "cartographer/mapping/2d/probability_grid_range_data_inserter_2d.h"
#include "gtest/gtest.h"

namespace cartographer {
namespace mapping {
namespace {

proto::ProbabilityGridRangeDataInserterOptions2D Options(bool free = true) {
  proto::ProbabilityGridRangeDataInserterOptions2D o;
  o.set_hit_probability(.60);
  o.set_miss_probability(.47);
  o.set_insert_free_space(free);
  return o;
}

class MultiOriginTest : public ::testing::Test {
 protected:
  MultiOriginTest()
      : grid_(MapLimits(.01, {2., 2.}, CellLimits(400, 400)), &tables_),
        inserter_(Options()) {}
  float Probability(float x, float y) {
    return grid_.GetProbability(grid_.limits().GetCellIndex({x, y}));
  }
  void Seed(float x, float y) {
    grid_.SetProbability(grid_.limits().GetCellIndex({x, y}), .8f);
  }
  sensor::RangeData OffsetScan() {
    sensor::RangeData data{{.005f, .005f, 0.f}, {}, {}};
    data.returns.push_back({{1.005f, .005f, 0.f}});
    data.rays.push_back({{.005f, .22f, 0.f}, {1.005f, .005f, 0.f}, true});
    return data;
  }
  ValueConversionTables tables_;
  ProbabilityGrid grid_;
  ProbabilityGridRangeDataInserter2D inserter_;
};

TEST_F(MultiOriginTest, RepeatedOffsetRaysDoNotEraseNearbyPillar) {
  Seed(.505f, .005f);
  const auto scan = OffsetScan();
  for (int i = 0; i < 60; ++i) inserter_.Insert(scan, &grid_);
  EXPECT_NEAR(Probability(.505f, .005f), .8f, .001f);
}

TEST_F(MultiOriginTest, LegacySharedOriginReproducesPillarErasure) {
  Seed(.505f, .005f);
  auto scan = OffsetScan();
  scan.rays.clear();
  for (int i = 0; i < 60; ++i) inserter_.Insert(scan, &grid_);
  EXPECT_LT(Probability(.505f, .005f), .2f);
}

TEST_F(MultiOriginTest, RealFreeSpaceStillClearsMovedObstacle) {
  Seed(.505f, .115f);
  const auto scan = OffsetScan();
  for (int i = 0; i < 60; ++i) inserter_.Insert(scan, &grid_);
  EXPECT_LT(Probability(.505f, .115f), .2f);
}

TEST_F(MultiOriginTest, AllSensorsHitsTakePriorityOverCrossingMisses) {
  sensor::RangeData data{{0.f, 0.f, 0.f}, {}, {}};
  data.rays = {{{.005f, .505f, 0.f}, {1.005f, .505f, 0.f}, false},
               {{.505f, .005f, 0.f}, {.505f, .505f, 0.f}, true}};
  inserter_.Insert(data, &grid_);
  EXPECT_NEAR(Probability(.505f, .505f), .6f, .001f);
}

TEST_F(MultiOriginTest, DuplicatePointsUpdateCellOnlyOnce) {
  auto scan = OffsetScan();
  scan.rays.resize(720, scan.rays.front());
  inserter_.Insert(scan, &grid_);
  EXPECT_NEAR(Probability(1.005f, .005f), .6f, .001f);
}

TEST_F(MultiOriginTest, DisableFreeSpaceIsRespected) {
  Seed(.505f, .115f);
  ProbabilityGridRangeDataInserter2D hits_only(Options(false));
  hits_only.Insert(OffsetScan(), &grid_);
  EXPECT_NEAR(Probability(.505f, .115f), .8f, .001f);
}

TEST_F(MultiOriginTest, GridGrowsToIncludeOriginalSensorOrigin) {
  sensor::RangeData data{{0.f, 0.f, 0.f}, {}, {}};
  data.rays.push_back({{3.005f, .505f, 0.f}, {.505f, .505f, 0.f}, true});
  inserter_.Insert(data, &grid_);
  EXPECT_LT(Probability(2.505f, .505f), .5f);
  EXPECT_GT(Probability(.505f, .505f), .5f);
}

TEST_F(MultiOriginTest, TransformCropAndSerializationPreserveRayGeometry) {
  auto scan = OffsetScan();
  scan.rays.push_back({{.1f, .2f, 0.f}, {1.f, 0.f, 3.f}, false});
  const transform::Rigid3f pose(
      {1.f, 2.f, 0.f}, Eigen::Quaternionf(Eigen::AngleAxisf(.7f, Eigen::Vector3f::UnitZ())));
  const auto transformed = sensor::TransformRangeData(scan, pose);
  ASSERT_EQ(transformed.rays.size(), 2u);
  EXPECT_LT((transformed.rays[0].origin - pose * scan.rays[0].origin).norm(), 1e-6);
  EXPECT_LT((transformed.rays[0].endpoint - pose * scan.rays[0].endpoint).norm(), 1e-6);
  const auto cropped = sensor::CropRangeData(transformed, -1.f, 1.f);
  ASSERT_EQ(cropped.rays.size(), 1u);
  const auto restored = sensor::FromProto(sensor::ToProto(cropped));
  ASSERT_EQ(restored.rays.size(), 1u);
  EXPECT_LT((restored.rays[0].origin - cropped.rays[0].origin).norm(), 1e-6);
  EXPECT_LT((restored.rays[0].endpoint - cropped.rays[0].endpoint).norm(), 1e-6);
  EXPECT_TRUE(restored.rays[0].hit);
  EXPECT_TRUE(sensor::FromProto(sensor::proto::RangeData()).rays.empty());
}

TEST_F(MultiOriginTest, MissOnlyGeometryAndFlagSurviveSerialization) {
  auto scan = OffsetScan();
  scan.rays[0].hit = false;
  const auto restored = sensor::FromProto(sensor::ToProto(scan));
  ASSERT_EQ(restored.rays.size(), 1u);
  EXPECT_FALSE(restored.rays[0].hit);
  inserter_.Insert(restored, &grid_);
  EXPECT_LT(Probability(1.005f, .005f), .5f);
}

proto::ProbabilityGridRangeDataInserterOptions2D DistanceOptions(bool free = true) {
  auto options = Options(free);
  options.set_free_space_near_range(1.5);
  options.set_free_space_far_range(4.);
  options.set_far_miss_probability(.49);
  return options;
}

TEST_F(MultiOriginTest, NearClearingUnchangedEvenWithDistantEndpoint) {
  ProbabilityGridRangeDataInserter2D weighted(DistanceOptions());
  sensor::RangeData data{{0.f, 0.f, 0.f}, {}, {}};
  data.rays = {{{.005f, .005f, 0.f}, {6.005f, .005f, 0.f}, false}};
  weighted.Insert(data, &grid_);
  EXPECT_NEAR(Probability(.505f, .005f), .47f, .001f);
  EXPECT_NEAR(Probability(5.005f, .005f), .47f, .001f);
}

TEST_F(MultiOriginTest, FarObstaclePersistsLongerButStillClears) {
  ProbabilityGridRangeDataInserter2D weighted(DistanceOptions());
  Seed(.505f, .005f);
  sensor::RangeData data{{0.f, 0.f, 0.f}, {}, {}};
  data.rays = {{{5.005f, .005f, 0.f}, {.005f, .005f, 0.f}, false}};
  for (int i = 0; i < 15; ++i) weighted.Insert(data, &grid_);
  // Fixed .47 would fall below .5 after 12 insertions; .49 must not yet.
  EXPECT_GT(Probability(.505f, .005f), .65f);
  for (int i = 0; i < 80; ++i) weighted.Insert(data, &grid_);
  EXPECT_LT(Probability(.505f, .005f), .2f);
}

TEST_F(MultiOriginTest, NearEvidenceWinsRegardlessOfSensorOrdering) {
  ProbabilityGridRangeDataInserter2D weighted(DistanceOptions());
  sensor::RangeData data{{0.f, 0.f, 0.f}, {}, {}};
  data.rays = {{{5.005f, .005f, 0.f}, {.005f, .005f, 0.f}, false},
               {{.005f, .505f, 0.f}, {.005f, -.505f, 0.f}, false}};
  weighted.Insert(data, &grid_);
  EXPECT_NEAR(Probability(.005f, .005f), .47f, .001f);
  ValueConversionTables other_tables;
  ProbabilityGrid other(MapLimits(.01, {6., 2.}, CellLimits(800, 800)), &other_tables);
  std::swap(data.rays[0], data.rays[1]);
  weighted.Insert(data, &other);
  EXPECT_NEAR(other.GetProbability(other.limits().GetCellIndex({.005f, .005f})),
              Probability(.005f, .005f), .001f);
}

TEST_F(MultiOriginTest, WeightedHitsAndNoFreeSpacePreserveSemantics) {
  auto data = OffsetScan();
  data.rays[0].origin = {6.005f, .005f, 0.f};
  ProbabilityGridRangeDataInserter2D weighted(DistanceOptions(false));
  Seed(.505f, .005f);
  weighted.Insert(data, &grid_);
  EXPECT_NEAR(Probability(1.005f, .005f), .6f, .001f);
  EXPECT_NEAR(Probability(.505f, .005f), .8f, .001f);
}

TEST_F(MultiOriginTest, WeightedDuplicateFarRaysStillUpdateOnlyOnce) {
  ProbabilityGridRangeDataInserter2D weighted(DistanceOptions());
  sensor::RangeData data{{0.f, 0.f, 0.f}, {}, {}};
  data.rays.resize(720, {{5.005f, .005f, 0.f}, {.005f, .005f, 0.f}, false});
  weighted.Insert(data, &grid_);
  EXPECT_NEAR(Probability(.005f, .005f), .47f, .001f);
}

TEST_F(MultiOriginTest, DistanceOptionsDoNotChangeLegacySerializedScans) {
  ProbabilityGridRangeDataInserter2D weighted(DistanceOptions());
  sensor::RangeData data{{5.005f, .005f, 0.f}, {}, {}};
  data.misses.push_back({{.005f, .005f, 0.f}});
  weighted.Insert(data, &grid_);
  EXPECT_NEAR(Probability(.005f, .005f), .47f, .001f);
}

TEST_F(MultiOriginTest, InvalidDistanceOptionsFailClosed) {
  auto bad = DistanceOptions();
  bad.set_far_miss_probability(.5);
  EXPECT_DEATH(ProbabilityGridRangeDataInserter2D invalid(bad), "Check failed");
}

TEST_F(MultiOriginTest, UnknownFarSpaceConvergesLikeNearSpace) {
  ProbabilityGridRangeDataInserter2D weighted(DistanceOptions());
  sensor::RangeData data{{0.f, 0.f, 0.f}, {}, {}};
  data.rays = {{{.005f, .005f, 0.f}, {6.005f, .005f, 0.f}, false}};
  for (int i = 0; i < 10; ++i) weighted.Insert(data, &grid_);
  EXPECT_NEAR(Probability(.505f, .005f), Probability(5.005f, .005f), .001f);
  EXPECT_LT(Probability(5.005f, .005f), .25f);
  EXPECT_FALSE(grid_.IsKnown(grid_.limits().GetCellIndex({5.005f, .505f})));
}

TEST_F(MultiOriginTest, WeakOccupiedFarCellStillReceivesWeakClearing) {
  ProbabilityGridRangeDataInserter2D weighted(DistanceOptions());
  grid_.SetProbability(grid_.limits().GetCellIndex({.505f, .005f}), .55f);
  sensor::RangeData data{{0.f, 0.f, 0.f}, {}, {}};
  data.rays = {{{5.005f, .005f, 0.f}, {.005f, .005f, 0.f}, false}};
  for (int i = 0; i < 2; ++i) weighted.Insert(data, &grid_);
  EXPECT_GT(Probability(.505f, .005f), .52f);
}

}  // namespace
}  // namespace mapping
}  // namespace cartographer
