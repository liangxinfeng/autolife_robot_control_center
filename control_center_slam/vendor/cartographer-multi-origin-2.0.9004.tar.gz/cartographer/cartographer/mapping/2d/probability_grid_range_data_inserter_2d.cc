/*
 * Copyright 2016 The Cartographer Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "cartographer/mapping/2d/probability_grid_range_data_inserter_2d.h"

#include <cstdlib>
#include <array>
#include <cmath>

#include "Eigen/Core"
#include "Eigen/Geometry"
#include "cartographer/mapping/2d/xy_index.h"
#include "cartographer/mapping/internal/2d/ray_to_pixel_mask.h"
#include "cartographer/mapping/probability_values.h"
#include "glog/logging.h"

namespace cartographer {
namespace mapping {
namespace {

// Factor for subpixel accuracy of start and end point for ray casts.
constexpr int kSubpixelScale = 1000;

void GrowAsNeeded(const sensor::RangeData& range_data,
                  ProbabilityGrid* const probability_grid) {
  Eigen::AlignedBox2f bounding_box(range_data.origin.head<2>());
  // Padding around bounding box to avoid numerical issues at cell boundaries.
  constexpr float kPadding = 1e-6f;
  for (const sensor::RangefinderPoint& hit : range_data.returns) {
    bounding_box.extend(hit.position.head<2>());
  }
  for (const sensor::RangefinderPoint& miss : range_data.misses) {
    bounding_box.extend(miss.position.head<2>());
  }
  for (const auto& ray : range_data.rays) {
    bounding_box.extend(ray.origin.head<2>());
    bounding_box.extend(ray.endpoint.head<2>());
  }
  probability_grid->GrowLimits(bounding_box.min() -
                               kPadding * Eigen::Vector2f::Ones());
  probability_grid->GrowLimits(bounding_box.max() +
                               kPadding * Eigen::Vector2f::Ones());
}

void CastRays(const sensor::RangeData& range_data,
              const std::vector<uint16>& hit_table,
              const std::vector<uint16>& miss_table,
              const std::vector<std::vector<uint16>>& distance_tables,
              const std::vector<double>& squared_boundaries,
              const bool insert_free_space, ProbabilityGrid* probability_grid) {
  GrowAsNeeded(range_data, probability_grid);

  const MapLimits& limits = probability_grid->limits();
  const double superscaled_resolution = limits.resolution() / kSubpixelScale;
  const MapLimits superscaled_limits(
      superscaled_resolution, limits.max(),
      CellLimits(limits.cell_limits().num_x_cells * kSubpixelScale,
                 limits.cell_limits().num_y_cells * kSubpixelScale));
  if (!range_data.rays.empty()) {
    // Apply ALL sensors' hits first. FinishUpdate remains outside CastRays,
    // preserving upstream's once-per-cell update and hit-over-miss priority.
    for (const auto& ray : range_data.rays) {
      if (ray.hit) {
        probability_grid->ApplyLookupTable(
            superscaled_limits.GetCellIndex(ray.endpoint.head<2>()) /
                kSubpixelScale,
            hit_table);
      }
    }
    if (insert_free_space) {
      // Defer weaker evidence so a near ray always wins over a far ray,
      // independent of sensor ordering. Hit priority and one update per cell
      // remain enforced by ProbabilityGrid's existing update marker.
      std::array<std::vector<Eigen::Array2i>, 3> deferred;
      for (const auto& ray : range_data.rays) {
        const auto cells = RayToPixelMask(
            superscaled_limits.GetCellIndex(ray.origin.head<2>()),
            superscaled_limits.GetCellIndex(ray.endpoint.head<2>()),
            kSubpixelScale);
        for (const auto& cell : cells) {
          int band = 0;
          if (!distance_tables.empty()) {
            const double distance_squared =
                (limits.GetCellCenter(cell) -
                 ray.origin.head<2>()).squaredNorm();
            while (band < 3 && distance_squared > squared_boundaries[band]) {
              ++band;
            }
          }
          if (band == 0) {
            probability_grid->ApplyLookupTable(cell, miss_table);
          } else {
            deferred[band - 1].push_back(cell);
          }
        }
      }
      for (int band = 1; band < 4 && !distance_tables.empty(); ++band) {
        for (const auto& cell : deferred[band - 1]) {
          probability_grid->ApplyLookupTable(cell, distance_tables[band - 1]);
        }
      }
    }
    return;
  }
  const Eigen::Array2i begin =
      superscaled_limits.GetCellIndex(range_data.origin.head<2>());
  // Compute and add the end points.
  std::vector<Eigen::Array2i> ends;
  ends.reserve(range_data.returns.size());
  for (const sensor::RangefinderPoint& hit : range_data.returns) {
    ends.push_back(superscaled_limits.GetCellIndex(hit.position.head<2>()));
    probability_grid->ApplyLookupTable(ends.back() / kSubpixelScale, hit_table);
  }

  if (!insert_free_space) {
    return;
  }

  // Now add the misses.
  for (const Eigen::Array2i& end : ends) {
    std::vector<Eigen::Array2i> ray =
        RayToPixelMask(begin, end, kSubpixelScale);
    for (const Eigen::Array2i& cell_index : ray) {
      probability_grid->ApplyLookupTable(cell_index, miss_table);
    }
  }

  // Finally, compute and add empty rays based on misses in the range data.
  for (const sensor::RangefinderPoint& missing_echo : range_data.misses) {
    std::vector<Eigen::Array2i> ray = RayToPixelMask(
        begin, superscaled_limits.GetCellIndex(missing_echo.position.head<2>()),
        kSubpixelScale);
    for (const Eigen::Array2i& cell_index : ray) {
      probability_grid->ApplyLookupTable(cell_index, miss_table);
    }
  }
}
}  // namespace

proto::ProbabilityGridRangeDataInserterOptions2D
CreateProbabilityGridRangeDataInserterOptions2D(
    common::LuaParameterDictionary* parameter_dictionary) {
  proto::ProbabilityGridRangeDataInserterOptions2D options;
  options.set_hit_probability(
      parameter_dictionary->GetDouble("hit_probability"));
  options.set_miss_probability(
      parameter_dictionary->GetDouble("miss_probability"));
  options.set_insert_free_space(
      parameter_dictionary->HasKey("insert_free_space")
          ? parameter_dictionary->GetBool("insert_free_space")
          : true);
  CHECK_GT(options.hit_probability(), 0.5);
  CHECK_LT(options.miss_probability(), 0.5);
  if (parameter_dictionary->HasKey("distance_weighted_free_space")) {
    auto distance = parameter_dictionary->GetDictionary("distance_weighted_free_space");
    options.set_free_space_near_range(distance->GetDouble("near_range"));
    options.set_free_space_far_range(distance->GetDouble("far_range"));
    options.set_far_miss_probability(distance->GetDouble("far_miss_probability"));
  }
  return options;
}

ProbabilityGridRangeDataInserter2D::ProbabilityGridRangeDataInserter2D(
    const proto::ProbabilityGridRangeDataInserterOptions2D& options)
    : options_(options),
      hit_table_(ComputeLookupTableToApplyCorrespondenceCostOdds(
          Odds(options.hit_probability()))),
      miss_table_(ComputeLookupTableToApplyCorrespondenceCostOdds(
          Odds(options.miss_probability()))) {
  if (options.free_space_near_range() != 0.) {
    CHECK(std::isfinite(options.free_space_near_range()));
    CHECK(std::isfinite(options.free_space_far_range()));
    CHECK_GT(options.free_space_near_range(), 0.);
    CHECK_GT(options.free_space_far_range(), options.free_space_near_range());
    CHECK_GE(options.far_miss_probability(), options.miss_probability());
    CHECK_LT(options.far_miss_probability(), .5);
    for (int i = 0; i < 3; ++i) {
      const double boundary = options.free_space_near_range() +
          i * .5 * (options.free_space_far_range() - options.free_space_near_range());
      distance_squared_boundaries_.push_back(boundary * boundary);
      const double probability = options.miss_probability() +
          (i + 1) / 3. * (options.far_miss_probability() - options.miss_probability());
      distance_miss_tables_.push_back(
          ComputeLookupTableToApplyCorrespondenceCostOdds(Odds(probability)));
    }
  }
}

void ProbabilityGridRangeDataInserter2D::Insert(
    const sensor::RangeData& range_data, GridInterface* const grid) const {
  ProbabilityGrid* const probability_grid = static_cast<ProbabilityGrid*>(grid);
  CHECK(probability_grid != nullptr);
  // By not finishing the update after hits are inserted, we give hits priority
  // (i.e. no hits will be ignored because of a miss in the same cell).
  CastRays(range_data, hit_table_, miss_table_, distance_miss_tables_,
           distance_squared_boundaries_, options_.insert_free_space(),
           probability_grid);
  probability_grid->FinishUpdate();
}

}  // namespace mapping
}  // namespace cartographer
