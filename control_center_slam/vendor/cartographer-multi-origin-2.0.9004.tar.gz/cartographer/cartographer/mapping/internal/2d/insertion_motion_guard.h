// Copyright 2026. Licensed under the Apache License, Version 2.0.
#ifndef CARTOGRAPHER_MAPPING_INSERTION_MOTION_GUARD_H_
#define CARTOGRAPHER_MAPPING_INSERTION_MOTION_GUARD_H_
#include <cmath>
#include <limits>
#include <deque>

namespace cartographer {
namespace mapping {
// Quality gate only: matching/extrapolation continue while insertion is paused.
class InsertionMotionGuard {
 public:
  InsertionMotionGuard(bool enabled, double linear, double angular,
                       double settle, double age)
      : enabled_(enabled), linear_(linear), angular_(angular),
        settle_(settle), age_(age) {}
  void Observe(double t, double linear, double angular) {
    if (!std::isfinite(t)) { history_.clear(); return; }
    if (!history_.empty() && t <= history_.back().time) history_.clear();
    const bool valid = std::isfinite(linear) && std::isfinite(angular) &&
                       std::abs(linear) <= linear_ && std::abs(angular) <= angular_;
    history_.push_back({t, valid});
    while (history_.size() > 256 ||
           (!history_.empty() && t-history_.front().time > 2.+settle_+age_))
      history_.pop_front();
  }
  bool CanInsert(double t) const {
    if (!enabled_) return true;
    if (!std::isfinite(t) || history_.empty()) return false;
    // The range collator can emit a scan older than the latest odometry.
    // Evaluate motion at acquisition time, never against future odometry.
    auto it = history_.rbegin();
    while (it != history_.rend() && it->time > t) ++it;
    if (it == history_.rend() || t-it->time > age_) return false;
    const double until = it->time-settle_;
    double previous = it->time;
    for (; it != history_.rend(); ++it) {
      if (!it->valid || previous-it->time > age_) return false;
      if (it->time <= until) return true;
      previous = it->time;
    }
    return false;
  }
 private:
  struct Observation { double time; bool valid; };
  bool enabled_;
  double linear_, angular_, settle_, age_;
  std::deque<Observation> history_;
};
}  // namespace mapping
}  // namespace cartographer
#endif
