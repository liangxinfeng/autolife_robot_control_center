// Copyright 2026. Licensed under the Apache License, Version 2.0.
#include "cartographer/mapping/internal/2d/insertion_motion_guard.h"
#include "gtest/gtest.h"
namespace cartographer { namespace mapping { namespace {
TEST(InsertionGuard, FastTurnNeverWritesButRecoversAfterSettling) {
 InsertionMotionGuard g(true,.22,.10,.2,.2);
 for(int i=0;i<20;++i)g.Observe(1.+i*.016,0,.45);
 EXPECT_FALSE(g.CanInsert(1.31));
 for(int i=20;i<28;++i)g.Observe(1.+i*.016,0,0);
 EXPECT_FALSE(g.CanInsert(1.45));
 for(int i=28;i<42;++i)g.Observe(1.+i*.016,0,0);
 EXPECT_TRUE(g.CanInsert(1.66));
}
TEST(InsertionGuard, StaleMissingFutureAndInvalidOdometryAreRejected) {
 InsertionMotionGuard g(true,.22,.10,.2,.2);
 EXPECT_FALSE(g.CanInsert(1.));
 for(int i=0;i<30;++i)g.Observe(1.+i*.016,.18,0);
 EXPECT_TRUE(g.CanInsert(1.47));
 EXPECT_FALSE(g.CanInsert(1.8));
 EXPECT_FALSE(g.CanInsert(1.1));
 g.Observe(1.48,std::numeric_limits<double>::infinity(),0);
 EXPECT_FALSE(g.CanInsert(1.49));
}
TEST(InsertionGuard, ReorderedOrGappedTimeNeedsNewWarmup) {
 InsertionMotionGuard g(true,.22,.10,.2,.2);
 for(int i=0;i<30;++i)g.Observe(1.+i*.016,0,0);
 EXPECT_TRUE(g.CanInsert(1.47));
 g.Observe(.5,0,0);EXPECT_FALSE(g.CanInsert(.5));
 g.Observe(4.,0,0);EXPECT_FALSE(g.CanInsert(4.));
}
TEST(InsertionGuard, DisabledKeepsUpstreamBehavior) {
 InsertionMotionGuard g(false,0,0,0,0);EXPECT_TRUE(g.CanInsert(2.));
}
TEST(InsertionGuard, FastTranslationIsRejected) {
 InsertionMotionGuard g(true,.22,.10,.2,.2);
 for(int i=0;i<30;++i)g.Observe(1.+i*.016,.5,0);
 EXPECT_FALSE(g.CanInsert(1.47));
}
TEST(InsertionGuard, DelayedScanUsesItsOwnMotionHistory) {
 InsertionMotionGuard g(true,.22,.10,.2,.2);
 for(int i=0;i<40;++i)g.Observe(1.+i*.016,0,0);
 g.Observe(1.64,0,.5);
 EXPECT_TRUE(g.CanInsert(1.45));
 EXPECT_FALSE(g.CanInsert(1.65));
}
}}}
